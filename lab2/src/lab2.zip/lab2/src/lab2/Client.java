package lab2;

public abstract class Client {
	
	//creation of the abstract classes
	public abstract void readData();
	public abstract void processData();
	public abstract void printData();  
		
}
